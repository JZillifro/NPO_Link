from flask import Flask, redirect, session

app = Flask(__name__)
